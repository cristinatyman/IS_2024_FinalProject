using UnityEngine;

public class Pin : MonoBehaviour
{
    private Rigidbody rb;
    private bool isFallen;
    private Quaternion initialRotation;
    private Vector3 initialPosition;
    private float fallThreshold = 60f; //threshold for the rotation of the fallen pin

    private bool firstPin;
    public AudioSource source;
    public AudioClip clip;

    public int playerIndex; //pin realted to the player
    private PinManager pinManager;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        isFallen = false;
        initialRotation = transform.rotation;
        initialPosition = transform.position;
        pinManager = FindObjectOfType<PinManager>(); 
        firstPin = false;
    }

    void Update()
    {
        CheckIfFallen();
    }

    public void CheckIfFallen()
    {
        if (!isFallen && Quaternion.Angle(transform.rotation, initialRotation) > fallThreshold)
        {
            isFallen = true;
            gameObject.SetActive(false);
            pinManager.PinFallen(playerIndex); //notify the pinmanager
        }

        if (firstPin == false && isFallen == true) //if it's the first pin and it's fallen, then it plays the audioclip.
        {
            source.PlayOneShot(clip);
            firstPin = true;
        }
    }

    public void ResetPin()
    {
        isFallen = false;
        transform.position = initialPosition;
        transform.rotation = initialRotation;
        gameObject.SetActive(true);
        rb.velocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
    }

    void OnCollisionEnter(Collision collision)
    {
        CheckIfFallen();
    }
}
