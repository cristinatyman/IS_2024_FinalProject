using System.Collections;
using UnityEngine;

public class Ball : MonoBehaviour
{
    public float speed;
    private Rigidbody myBody;
    public bool thrown { get; set; }
    public float horizontalSpeed;
    public Vector3 restPosition;
    private Vector3 initialPosition;
    private Coroutine resetCoroutine;
    private PinManager pinManager;

    void Start()
    {
        myBody = GetComponent<Rigidbody>();
        initialPosition = transform.position; //initial position
        myBody.isKinematic = true;            //moves with the player
        pinManager = FindObjectOfType<PinManager>();
    }

    void Update()
    {
        if (!thrown && myBody.isKinematic)
        {
            BallMovement();
        }
    }

    public void SetPosition(Vector3 position)
    {
        transform.position = new Vector3(position.x, transform.position.y, position.z + 3f); //moving with the player (except for the y, since we are not using it)
    }

    void BallMovement()
    {
        float xAxis = Input.GetAxis("Horizontal");
        Vector3 position = transform.position;
        transform.position = position;
    }

    public void ThrowBall(Vector3 playerVelocity)
    {

        thrown = true;
        myBody.isKinematic = false; //now it moves alone
        myBody.velocity = new Vector3(playerVelocity.x * 5f, playerVelocity.y, playerVelocity.z * 5f); //velocity given by the player
        Debug.Log("Ball velocity set to: " + myBody.velocity);

        //Start the reset coroutine
        if (resetCoroutine != null)
        {
            StopCoroutine(resetCoroutine);
        }
        resetCoroutine = StartCoroutine(ResetBallAfterDelay(10f)); //Some delay if the ball is stopped or is missing
    }

    private IEnumerator ResetBallAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        if (thrown)
        {
            ResetBallPosition(false);
        }
    }
    
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("End"))
        {
            ResetBallPosition(false);
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Pin"))
        {
            Pin pin = collision.gameObject.GetComponent<Pin>();
            if (pin != null)
            {
                pin.CheckIfFallen();
            }
        }

        //Maintain vertical velocity to 0 in case of any other collision (lane, player...)
        else
        {
            Vector3 currentVelocity = myBody.velocity;
            currentVelocity.y = 0;
            myBody.velocity = currentVelocity;
        }

        Debug.Log("Collision with: " + collision.gameObject.name);
        Debug.Log("Collision impact force: " + collision.impulse);
        Debug.Log("Ball velocity after collision: " + myBody.velocity);
    }

    void ResetBallPosition(bool immediate)
    {
        thrown = false;
        myBody.isKinematic = true;
        transform.position = restPosition;
        myBody.velocity = Vector3.zero;

        // Stop the reset coroutine if it is running
        if (resetCoroutine != null)
        {
            StopCoroutine(resetCoroutine);
            resetCoroutine = null;
        }

        StartCoroutine(ResetPinsAfterDelay(0.5f)); //delay for pins after reset ball
    }

    private IEnumerator ResetPinsAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);

        if (pinManager != null)
        {
            pinManager.ResetPins(); //Reset pins
        }
    }
}
