using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class PinManager : MonoBehaviour
{
    //UI
    public Text player1ScoreText;
    public Text player2ScoreText;
    public Text roundText;
    public Text winnerText;

    private int player1FallenPins = 0;
    private int player2FallenPins = 0;

    private int currentRound = 1;
    private int totalRounds = 10;
    private bool gameEnded = false;

    private Pin[] pins;

    void Start()
    {
        pins = FindObjectsOfType<Pin>();
        UpdateRoundText();
        UpdateScoreText();
    }

    public void PinFallen(int playerIndex)
    {
        if (gameEnded)
            return;

        if (playerIndex == 1)
        {
            player1FallenPins++;
        }
        else if (playerIndex == 2)
        {
            player2FallenPins++;
        }

        UpdateScoreText();
    }

    public void UpdateRoundText()
    {
        roundText.text = "Round " + currentRound.ToString();
    }

    public void UpdateScoreText()
    {
        player1ScoreText.text = "Player 1: " + player1FallenPins.ToString();
        player2ScoreText.text = "Player 2: " + player2FallenPins.ToString();
    }

    public void IncrementRound()
    {
        currentRound++;
        if (currentRound > totalRounds)
        {
            EndGame(); //end game for 10 rounds (5 each player)
        }
        else
        {
            UpdateRoundText();
        }
    }

    public void ResetGame()
    {
        player1FallenPins = 0;
        player2FallenPins = 0;
        currentRound = 1;
        gameEnded = false;

        UpdateRoundText();
        UpdateScoreText();
        winnerText.text = "";
    }

    private IEnumerator ResetGameAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        ResetGame();
    }

    void EndGame()
    {
        if (player1FallenPins > player2FallenPins)
        {
            winnerText.text = "Player 1 wins!";
        }
        else if (player2FallenPins > player1FallenPins)
        {
            winnerText.text = "Player 2 wins!";
        }
        else
        {
            winnerText.text = "It's a tie!";
        }

        gameEnded = true;

        // Start coroutine to reset the game after a delay in order to show Winner Message
        StartCoroutine(ResetGameAfterDelay(5f)); // Delay of 5 seconds
    }

    public void ResetPins()
    {
        foreach (Pin pin in pins)
        {
            pin.ResetPin();
        }
        IncrementRound();
    }
}
